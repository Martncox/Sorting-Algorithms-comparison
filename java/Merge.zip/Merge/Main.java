// import java.io.File;
// import java.io.FileNotFoundException;
// import java.util.Scanner;

import java.util.Random;

public class Main {

    public static void printList(int[] numArr) {
        for (int element: numArr) {
            System.out.println(element);
        }
    }

    public static void isSorted(int[] numArr) {
        int k = 0;
        for (int i = 0; i < numArr.length - 1; i++) {
            if (numArr[i] > numArr[i+1]) {
                System.out.println("The array is not sorted.");
                return;
            }
            k++;
        }
        if (numArr[k-1] < numArr[k-2]) {
            System.out.println("The array is not sorted.");
            return;
        }
        System.out.println("The array is sorted.");
        return;
    }

    public static void merge(int[] numArr, int leftIdx, int midIdx, int rightIdx) {
        int endOfLeftList = midIdx - leftIdx + 1;
        int endOfRightList = rightIdx - midIdx;
        
        // int mergedIdx = leftIdx;

        // while (leftIter < endOfLeftList && rightIter < endOfRightList) {
        //     if (numArr[leftIter] <= numArr[rightIter]) {
        //         numArr[mergedIdx] = numArr
        //     }
        // }
        int[] leftArr = new int[endOfLeftList];
        int[] rightArr = new int[endOfRightList];

        for (int i = 0; i < leftArr.length; i++) {
            leftArr[i] = numArr[leftIdx + i];
        }
        for (int j = 0; j < rightArr.length; j++) {
            rightArr[j] = numArr[midIdx + 1 + j];
        }
        int leftIter = 0;
        int rightIter = 0;
        int mergedIdx = leftIdx;

        while (leftIter < leftArr.length && rightIter < rightArr.length) {
            if (leftArr[leftIter] <= rightArr[rightIter]) {
                numArr[mergedIdx] = leftArr[leftIter];
                leftIter++;
            }
            else {
                numArr[mergedIdx] = rightArr[rightIter];
                rightIter++;
            }
            mergedIdx++;
        }

        while (leftIter < leftArr.length) {
            numArr[mergedIdx] = leftArr[leftIter];
            leftIter++;
            mergedIdx++;
        }

        while (rightIter < rightArr.length) {
            numArr[mergedIdx] = rightArr[rightIter];
            rightIter++;
            mergedIdx++;
        }
    }

    public static void mergeSort(int[] numArr, int startIdx, int endIdx) {
        if (startIdx >= endIdx) {
            return;
        }

        int partition = startIdx + (endIdx - startIdx) / 2;

        mergeSort(numArr, startIdx, partition);
        mergeSort(numArr, partition+1, endIdx);
        merge(numArr, startIdx, partition, endIdx);
    }
    public static void main(String[] args) {

        //int i = 0;
        int[] numList = new int[2000]; // Size 1000 hardcoded; change later

        // try {
        //     File myObj = new File("lists/list1000.txt");
        //     Scanner myReader = new Scanner(myObj);
        //     while (myReader.hasNextLine() && i < numList.length) {
        //         String currLine = myReader.nextLine();
        //         // System.out.println(currLine);
        //         numList[i] = Integer.parseInt(currLine);
        //         i++;
        //     }
        //     myReader.close();
        // } catch (FileNotFoundException e) {
        //     System.out.println("An error occurred.");
        //     e.printStackTrace();
        // }

        // for (int x = 0; x < numList.length; x++) {
        //     System.out.println(numList[x]);
        // }

        //isSorted(numList);
        //System.out.println("Performing MergeSort on Numlist ... ");

        double totalDuration = 0.0;
        for (int j = 0; j < 16; j++) {
            for (int i = 0; i < numList.length; i++) {
                Random rand = new Random();
                numList[i] = rand.nextInt(2000) + 1;
            }
        
            double startTime = System.nanoTime();
            mergeSort(numList, 0, numList.length - 1);
            double endTime = System.nanoTime();
        //printList(numList);
        //isSorted(numList);

            double duration = endTime - startTime;
            duration /= 1000;
            //System.out.printf("Total Time: %.2f microseconds.", duration);
            totalDuration += duration;
        }

        double avgDuration = totalDuration / 16;
        
        System.out.printf("Total Time: %.2f microseconds.", avgDuration);

        //System.out.println(numList[999]);
    }
}
